#include "quachecksum32.h"

QuaChecksum32::~QuaChecksum32()
{
}
